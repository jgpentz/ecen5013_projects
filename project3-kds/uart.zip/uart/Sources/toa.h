#include <math.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

int itoa(int sup, char * buff, int radix);

int ftoa(float sup, char * buff, int after);
