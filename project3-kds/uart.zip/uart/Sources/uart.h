/*
 * uart.h
 *
 *  Created on: Apr 9, 2016
 *      Author: jimmy
 */

#ifndef SOURCES_UART_H_
#define SOURCES_UART_H_
#include "MKL25Z4.h"

void uart_init(uint32_t baud_rate);



#endif /* SOURCES_UART_H_ */
